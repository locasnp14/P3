//
//  Adversa.swift
//  ProjetoLP2373
//
//  Created by Lucas Pereira on 11/02/2022.
//



import Foundation
import SwiftUI






class pokemeu{
    
    @State var Nome : String
    @State var HP : Float
    @State var id : Int
    @State var Ataque : Float
    @State var Defesa : Float
    
    private var nomeimg = ""
    
    var Imagem: Image {
        
        Image(nomeimg)
        
    }
    

    init(Nome:String , HP:Float , id:Int , Ataque:Float , Defesa:Float ){
        self.Nome = Nome
        self.HP = HP
        self.id = id
        self.Ataque = Ataque
        self.Defesa = Defesa
       
    }
}


