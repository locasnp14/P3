//
//  PokeDetalhes.swift
//  ProjetoLP2373
//
//  Created by Lucas Pereira on 31/01/2022.
//

import SwiftUI




struct PokeDetalhes: View {
    
public var pokemone: Pokemon
   
   

    @State private var muda = false  
    var body: some View {
        ScrollView {
         
       

            CircleImage(image: pokemone.Imagem)
                .offset(y: -130)
                .padding(.bottom, -200)
            

            VStack(alignment: .leading) {
                Text(pokemone.Nome)
                    .font(.title)
                    .foregroundColor(.white)

                HStack {
                    Text(pokemone.Tipo)
                        .foregroundColor(.white)
                    Spacer()
                   
                }
                .font(.subheadline)
                .foregroundColor(.secondary)

                Divider()
                
                
                
                ProgressView("HP: \( pokemone.HP.tiraisso) ", value: pokemone.Ataque , total: 100.0)
                    .padding(.all)
                    .frame( height: 50)
                    .colorScheme(.dark)
                    .background(Color.black)
            
                    
                
                ProgressView("Ataque : \( pokemone.Ataque.tiraisso) ", value: pokemone.Ataque , total: 100.0)
                    .padding(.all)
                    .frame( height: 50)
                    .colorScheme(.dark)
                    .background(Color.black)
                    
                ProgressView("Defesa : \( pokemone.Defesa.tiraisso) ", value: pokemone.Defesa , total: 100.0)
                    .padding(.all)
                    .frame( height: 50)
                    .colorScheme(.dark)
                    .background(Color.black)
                    
                
                Divider()

                Text("Acerca deste Pokemon: ")
                    .font(.title2)
                    .padding(2)
                    .foregroundColor(.white)
                   
                Text(pokemone.Descricao)
                    .font(.subheadline)
                    .foregroundColor(.white)
            }
            .padding()
            .padding(.bottom, 20)
            
           
            
            NavigationLink(destination: Ola(pokemone: pokemone), isActive: $muda) {  }
            
            
            
            
            
            
            
            
            Button("Jogar com este pokemon") {
            
                muda = true
               
                
             
         
            }
                    .foregroundColor(.white)
                    .padding(.all)
                    .background(Color.green)
                    .cornerRadius(8)
                    .padding(.bottom, 50)

            
           
            
        }         .navigationTitle(pokemone.Nome)
        .navigationBarTitleDisplayMode(.inline)
        .background(.gray)
        
        
       
    }
    
}



