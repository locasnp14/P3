//
//  Ola.swift
//  ProjetoLP2373
//
//  Created by Lucas Pereira on 11/02/2022.
//

import SwiftUI

struct Ola: View {
    

    @State private var progressvalor: Float = 0
    
    @State public var ataca = false
 
    var pokemone: Pokemon

    
    var body: some View {
     
        
        
       
        
        ZStack{
            Image("grass")
                        .resizable()
                        .scaledToFill()
                        .edgesIgnoringSafeArea(.all)
                .navigationBarBackButtonHidden(true)
            
         
          
            VStack{
                HStack{
                    
                   
              
                    
                    VStack{
                        ProgressView("HP: \( pokeadversa.HP.tiraisso) ", value: pokeadversa.Ataque , total: 100.0)
                        ProgressView("Ataque: \( pokeadversa.Ataque.tiraisso) ", value: pokeadversa.Ataque , total: 100.0)
                        ProgressView("Defesa: \( pokeadversa.Defesa.tiraisso) ", value: pokeadversa.Ataque , total: 100.0)
                          
                    
                    }
                    
                    
                    adversario.Imagem
                        .resizable()
                        .frame(width: 120, height: 120)
                   
                    

                }.padding(.bottom, 250)
                    .frame(width: 250 , alignment: .topTrailing)
            }.padding(.bottom, 150)
                
            
            
            VStack{
                
               
                   
                HStack{
                    
                    pokemone.Imagem
                        .resizable()
                        .frame(width: 120, height: 120)
                  
                .frame(alignment: .leading)
                    
                    VStack{
                        ProgressView("HP: \( pokemone.HP.tiraisso) ", value: pokemone.Ataque , total: 100.0)
                        ProgressView("Ataque: \( pokemone.Ataque.tiraisso) ", value: pokemone.Ataque , total: 100.0)
                        ProgressView("Defesa: \( pokemone.Defesa.tiraisso) ", value: pokemone.Ataque , total: 100.0)
                          
                    
                    }
                
                    
                    
                    
                    
             
                } .frame(width: 250 , alignment: .bottomLeading)
                    .padding(.bottom, 50)
                
                
                
                
               Text("O pikachu levou dano")
                    .foregroundColor(.white)
                    .background(Color.black)
                    .padding(.bottom, 50)
                    
               
                Button("Atacar") {
                    
                    ataca = true
                    
                }
                
                .frame(width: 80.0)
                        .foregroundColor(.white)
                        .padding(.all, 11.0)
                        .background(Color.blue)
                        .cornerRadius(8)
                        
                     
               
                
                        
                
            }.padding(.top, 100)
               
            
            
           
           
        }
            
        .frame(width: UIScreen.screenWidth, height: UIScreen.screenHeight)
      
           
     
    }
}





