//
//  ContentView.swift
//  ProjetoLP2373
//
//  Created by Lucas Pereira on 31/01/2022.
//

import SwiftUI

extension UIScreen{
   static let screenWidth = UIScreen.main.bounds.size.width
   static let screenHeight = UIScreen.main.bounds.size.height
   static let screenSize = UIScreen.main.bounds.size
}

struct CircleImage: View {
    var image: Image
        
    var body: some View {
        image
            .fixedSize()
            .frame(width: UIScreen.screenWidth, height: 350)
            
            .padding(.top, 150)
          
            .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
            .overlay {
                Circle().stroke(.white, lineWidth: 2)
                
                    
                
                
            }
            .shadow(radius: 3)
            .padding(.top, 50)
            
        
    }
}

