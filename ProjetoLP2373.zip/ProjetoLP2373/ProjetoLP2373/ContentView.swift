//
//  ContentView.swift
//  ProjetoLP2373
//
//  Created by Lucas Pereira on 31/01/2022.
//

import SwiftUI

struct ContentView: View {
    
    var body: some View {
        PokeLista()
    }
}

