//
//  PokeRow.swift
//  ProjetoLP2373
//
//  Created by Lucas Pereira on 31/01/2022.
//

import SwiftUI

struct PokeRow: View {
    public var pokemone: Pokemon

    var body: some View {
        
        HStack {
            pokemone.Imagem
                .resizable()
                .frame(width: 50, height: 50)
            Text(pokemone.Nome)

            Spacer()
        }
    }
}


