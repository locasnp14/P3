//
//  PokeLista.swift
//  ProjetoLP2373
//
//  Created by Lucas Pereira on 31/01/2022.
//

import SwiftUI

struct PokeLista: View {
    

    var body: some View {
        NavigationView {
            List(pokedados) { Pokemon in
                NavigationLink {
                    PokeDetalhes(pokemone: Pokemon )
                } label: {
                    PokeRow(pokemone: Pokemon)
                }
            }
            .navigationTitle("Pokedex")
        }
    }
}



