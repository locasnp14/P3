//
//  porrada.swift
//  ProjetoLP2373
//
//  Created by Lucas Pereira on 12/02/2022.
//

import Foundation
import SwiftUI

import UIKit


class fight {
    
        var Nomeeu : String
        var Nomeadversario : String
        var HPeu : Float
        var HPadversario : Float
        var ideu : Int
        var idadversario : Int
        var Ataqueeu : Float
        var Ataqueadversario : Float
        var Defesaeu : Float
        var Defesaadversario : Float
        
        private var nomeimg = ""
        
        var Imagem: Image {
            
            Image(nomeimg)
            
        }
        

    init(Nomeeu: String , Nomeadversario: String , HPeu: Float , HPadversario: Float , ideu: Int , idadversario: Int , Ataqueeu: Float , Ataqueadversario: Float , Defesaeu: Float , Defesaadversario: Float){
           
        self.Nomeeu = Nomeeu
        self.Nomeadversario = Nomeadversario
        self.HPeu = HPeu
        self.HPadversario = HPadversario
        self.ideu = ideu
        self.idadversario = idadversario
        self.Ataqueeu = Ataqueeu
        self.Ataqueadversario = Ataqueadversario
        self.Defesaeu = Defesaeu
        self.Defesaadversario = Defesaadversario
       
           
        }
    }




/*func bife(){
    
    if(){
        
        
    }
    
    
    
}
    */
