//
//  ProjetoLP2373App.swift
//  ProjetoLP2373
//
//  Created by Lucas Pereira on 31/01/2022.
//

import SwiftUI

@main

struct ProjetoLP2373App: App {
    
    var body: some Scene {
        
        WindowGroup {
            
            ContentView()
        }
    }
}
