//
//  Pokemons.swift
//  ProjetoLP2373
//
//  Created by Lucas Pereira on 31/01/2022.
//

import Foundation
import SwiftUI

var pokebusca: [eu] = load("Pokemonhes.json")

extension Float {
    var tiraisso: String {
       return self.truncatingRemainder(dividingBy: 1) == 0 ? String(format: "%.0f", self) : String(self)
    }
}



struct Pokemon: Hashable, Codable, Identifiable{
 
    var Nome: String
    var Tipo: String
    var HP: Float
    var id: Int
    var Ataque: Float
    var Defesa: Float
    var Forte: String
    var Fraco: String
    var Descricao: String
    
    private var nomeimg: String
    
    var Imagem: Image {
        
        Image(nomeimg)
        
    }

}




class eu : Decodable {
    
    var Nome : String
    var HP : Float
    var id : Int
    var Ataque : Float
    var Defesa : Float
    
    private var nomeimg = ""
    
    var Imagem: Image {
        
        Image(nomeimg)
        
    }
    

    init(Nome:String , HP:Float , id:Int , Ataque:Float , Defesa:Float ){
        self.Nome = Nome
        self.HP = HP
        self.id = id
        self.Ataque = Ataque
        self.Defesa = Defesa
       
    }
}





